HOMEWORK 2: HOCKEY CLASSES


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



DESCRIPTION OF 3RD STATISTIC:
Please be concise! (< 200 words)
What question you are trying to answer with your statistic? 
What data did you need to organize? 
What was interesting or challenging about the implementation of this statistic? 



NAME OF FILE WITH SAMPLE OUTPUT FROM 3RD STATISTIC:
Be sure to select (or create) a dataset with interesting results


< insert filename, file is included with submission >



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

